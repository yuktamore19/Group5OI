package com.order.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.order.exception.CustomerNotFoundException;
import com.order.exception.OrderNotFoundException;
import com.order.exception.StoreNotFoundException;
import com.order.model.Customers;
import com.order.model.Orders;
import com.order.model.Stores;
import com.order.services.CustomerService;
import com.order.services.OrderService;
import com.order.services.StoreService;

@Controller
@RequestMapping("/api/v1/orders")
public class OrderController {
	
	@Autowired
	OrderService orderService;

	@Autowired
	CustomerService customerService;
	
	@Autowired
	StoreService storeService;
	
	  @GetMapping("/all")
	  public ResponseEntity<List<Orders>> getAllOrders(){
		return new ResponseEntity<List<Orders>>(orderService.getAllOrders(),HttpStatus.OK);
		  
	  }
	  
	  @GetMapping("/{orderId}")
		public ResponseEntity<Orders> getOrderById(@PathVariable("orderId") int orderId) throws OrderNotFoundException{
			return new ResponseEntity<Orders> (orderService.getOrderById(orderId),HttpStatus.OK);
		}
		
		/*
		 * @PostMapping("/") public ResponseEntity<Orders> createOrders(@RequestBody
		 * Orders orders){ orderService.createOrders(orders); return new
		 * ResponseEntity<Orders>(HttpStatus.CREATED);
		 * 
		 * }
		 */
		 
	  
		
		/*
		 * @PostMapping("/{customer_id}/{storeId}/") public ResponseEntity<Orders>
		 * createOrders(@PathVariable("customer_id") int
		 * customer_id,@PathVariable("storeId") int storeId,@RequestBody Orders orders)
		 * throws CustomerNotFoundException, StoreNotFoundException{
		 * 
		 *  Customers cust=customerService.getCustomerById(customer_id); Stores
		 * sto=storeService.getStoreById(storeId); Orders
		 * orderAdd=orderService.createOrders(orders); System.out.println(sto);
		 * System.out.println(cust); orderAdd.setCustomers(cust);
		 * orderAdd.setStores(sto); return new
		 * ResponseEntity<Orders>(orderAdd,HttpStatus.CREATED);
		 * 
		 * }
		 */
		 
		  
	 }

	  

