package com.order.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.exception.OrderNotFoundException;
import com.order.model.Orders;
import com.order.repository.OrdersRepository;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	OrdersRepository ordersRepository;
	
	@Override
	public Orders getOrderById(int orderId) throws OrderNotFoundException{
		if(ordersRepository.findById(orderId).isEmpty())
			throw new OrderNotFoundException("the order with "+orderId+"does not extis");
		return ordersRepository.findById(orderId).get();
	}

	@Override
	public List<Orders> getAllOrders() {
		return ordersRepository.findAll();
	}

	@Override
	public Orders createOrders(Orders orders) {
		  return ordersRepository.save(orders);
		
	}

	@Override
	public Orders updateOrders(Orders orders) throws OrderNotFoundException {
		if(ordersRepository.findById(orders.getOrderId()).isEmpty())
			throw new OrderNotFoundException("the order with "+orders.getOrderId()+"does not extis");
		return ordersRepository.save(orders);
		
	}

	@Override
	public void deleteOrders(int orderId) throws OrderNotFoundException {
		if(ordersRepository.findById(orderId).isEmpty())
			throw new OrderNotFoundException("the order with "+orderId+"does not extis");
		 ordersRepository.delete(ordersRepository.findById(orderId).get());
		
	}

	
}
