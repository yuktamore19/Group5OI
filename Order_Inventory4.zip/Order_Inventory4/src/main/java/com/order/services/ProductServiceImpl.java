package com.order.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.order.exception.ProductNotFoundException;
import com.order.model.Products;
import com.order.repository.ProductsRepository;

public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductsRepository productsRepository;
	
	@Override
	public Products getProductById(int productId) throws ProductNotFoundException{
		if(productsRepository.findById((long) productId).isEmpty())
			throw new ProductNotFoundException("the order with "+productId+"does not extis");
		return productsRepository.findById((long) productId).get();
	}

	@Override
	public List<Products> getAllProducts() {
		return productsRepository.findAll();
	}

	@Override
	public void createProducts(Products products) {
		 productsRepository.save(products);
		
	}

	@Override
	public Products updateProducts(Products products) throws ProductNotFoundException {
		if(productsRepository.findById(products.getProductId()).isEmpty())
			throw new ProductNotFoundException("the order with "+products.getProductId()+"does not extis");
		return productsRepository.save(products);
		
	}

	@Override
	public void deleteProducts(int productId) throws ProductNotFoundException {
		if(productsRepository.findById((long) productId).isEmpty())
			throw new ProductNotFoundException("the order with "+productId+"does not extis");
		 productsRepository.delete(productsRepository.findById((long) productId).get());
		
	}

	
}
