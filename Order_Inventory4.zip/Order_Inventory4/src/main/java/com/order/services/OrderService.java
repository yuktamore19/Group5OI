package com.order.services;

import java.util.*;

import com.order.exception.OrderNotFoundException;
import com.order.model.Customers;
import com.order.model.Orders;


public interface OrderService {

	Orders getOrderById(int orderId) throws OrderNotFoundException;
	List<Orders> getAllOrders();
	Orders createOrders(Orders orders);
	Orders updateOrders(Orders orders) throws OrderNotFoundException;
	void deleteOrders(int orderId) throws OrderNotFoundException;
	
}
