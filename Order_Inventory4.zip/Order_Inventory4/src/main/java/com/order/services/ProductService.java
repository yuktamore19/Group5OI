package com.order.services;

import java.util.List;

import com.order.exception.ProductNotFoundException;
import com.order.model.Products;

public interface ProductService {

	Products getProductById(int productId) throws ProductNotFoundException;
	List<Products> getAllProducts();
	void createProducts(Products products);
	Products updateProducts(Products products) throws ProductNotFoundException;
	void deleteProducts(int productId) throws ProductNotFoundException;
}
