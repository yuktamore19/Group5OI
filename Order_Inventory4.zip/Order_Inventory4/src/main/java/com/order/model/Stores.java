package com.order.model;

import javax.persistence.*;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

@Entity
@Table(name = "STORES")
public class Stores {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "STORE_ID")
    private int storeId;

    @Column(name = "STORE_NAME",nullable=false)
    private String storeName;

    @Column(name = "WEB_ADDRESS")
    private String webAddress;

    @Column(name = "PHYSICAL_ADDRESS")
    private String physicalAddress;

  

	@Column(name = "LATITUDE",precision=9 ,scale=6)
    private BigDecimal latitude;

    @Column(name = "LONGITUDE" ,precision=9 ,scale=6)
    private BigDecimal longitude;

    @Lob
    @Column(name = "LOGO")
    private byte[] logo;

    @Column(name = "LOGO_MIME_TYPE")
    private String logoMimeType;

    @Column(name = "LOGO_FILENAME")
    private String logoFilename;

    @Column(name = "LOGO_CHARSET")
    private String logoCharset;

    @Column(name = "LOGO_LAST_UPDATED")
    private Date logoLastUpdated;

    @OneToMany(mappedBy = "stores", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Inventory> inventory;

    @OneToMany(mappedBy = "stores", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Shipments> shipments;
    
    @OneToMany(mappedBy = "stores", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Orders> orders;
    
    public List<Shipments> getShipments() {
  		return shipments;
  	}

  	public void setShipments(List<Shipments> shipments) {
  		this.shipments = shipments;
  	}

  	public List<Orders> getOrders() {
  		return orders;
  	}

  	public void setOrders(List<Orders> orders) {
  		this.orders = orders;
  	}
    public int getStoreId() {
        return storeId;
    }

    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getWebAddress() {
        return webAddress;
    }

    public void setWebAddress(String webAddress) {
        this.webAddress = webAddress;
    }

    public String getPhysicalAddress() {
        return physicalAddress;
    }

    public void setPhysicalAddress(String physicalAddress) {
        this.physicalAddress = physicalAddress;
    }

  

    public byte[] getLogo() {
        return logo;
    }

    public void setLogo(byte[] logo) {
        this.logo = logo;
    }

    public String getLogoMimeType() {
        return logoMimeType;
    }

    public void setLogoMimeType(String logoMimeType) {
        this.logoMimeType = logoMimeType;
    }

    public String getLogoFilename() {
        return logoFilename;
    }

    public void setLogoFilename(String logoFilename) {
        this.logoFilename = logoFilename;
    }

    public String getLogoCharset() {
        return logoCharset;
    }

    public void setLogoCharset(String logoCharset) {
        this.logoCharset = logoCharset;
    }

    public Date getLogoLastUpdated() {
        return logoLastUpdated;
    }

    public void setLogoLastUpdated(Date logoLastUpdated) {
        this.logoLastUpdated = logoLastUpdated;
    }

    public List<Inventory> getInventory() {
        return inventory;
    }

    public void setInventory(List<Inventory> inventory) {
        this.inventory = inventory;
    }

	public BigDecimal getLatitude() {
		return latitude;
	}

	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	public BigDecimal getLongitude() {
		return longitude;
	}

	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}
    
    
    
}
