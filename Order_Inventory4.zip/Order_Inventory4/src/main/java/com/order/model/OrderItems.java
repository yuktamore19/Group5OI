package com.order.model;

import javax.persistence.*;

@Entity
@Table(name = "ORDER_ITEMS")

public class OrderItems {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    

    @Column(name = "LINE_ITEM_ID")
    private int lineItemId;

    public Orders getOrders() {
		return orders;
	}

	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	public Shipments getShipments() {
		return shipments;
	}

	public void setShipments(Shipments shipments) {
		this.shipments = shipments;
	}

	public Products getProducts() {
		return products;
	}

	public void setProducts(Products products) {
		this.products = products;
	}

	@Column(name = "UNIT_PRICE")
    private double unitPrice;

    @Column(name = "QUALITY")
    private int quantity;

  
	
	  @ManyToOne
	  @JoinColumn(name ="ORDER_ID")
	  private Orders orders;
	 

     @ManyToOne(cascade=CascadeType.ALL)
     @JoinColumn(name="SHIPMENT_ID")
     private Shipments shipments;
     
		
		  @ManyToOne(cascade=CascadeType.ALL)
		  @JoinColumn(name="PRODUCT_ID")
		  private Products products;
		 
     
	public int getLineItemId() {
		return lineItemId;
	}

	public void setLineItemId(int lineItemId) {
		this.lineItemId = lineItemId;
	}

	

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}

 

 