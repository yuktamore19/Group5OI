package com.order.model;

import java.util.List;

import javax.persistence.CascadeType;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;

import javax.persistence.GenerationType;

import javax.persistence.Id;

import javax.persistence.JoinColumn;

import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

 

@Entity
@Table(name="SHIPMENTS")
public class Shipments {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)

	@Column(name="SHIPMENT_ID",nullable=false)
	private int shipment_id;

	

	@Column(name="DELIVERY_ADDRESS",nullable=false)
	private String delivery_address;


	@Column(name="SHIPMENT_STATUS",nullable=false)
	private String shipment_status;

	
	
   public List<OrderItems> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItems> orderItems) {
		this.orderItems = orderItems;
	}

	public Customers getCustomers() {
		return customers;
	}

	public void setCustomers(Customers customers) {
		this.customers = customers;
	}

	 @OneToMany(mappedBy = "shipments", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	 private List<OrderItems> orderItems;
	 
	
  @ManyToOne(cascade=CascadeType.ALL)
   @JoinColumn(name="STORE_ID")
   private Stores stores;
   
   @ManyToOne(cascade=CascadeType.ALL)
   @JoinColumn(name="CUSTOMER_ID")
   private Customers customers;

	public Stores getStores() {
	return stores;
}

public void setStores(Stores stores) {
	this.stores = stores;
}

	public int getShipment_id() {
		return shipment_id;
	}

	public void setShipment_id(int shipment_id) {
		this.shipment_id = shipment_id;
	}




	public String getDelivery_address() {
		return delivery_address;
	}

 

	public void setDelivery_address(String delivery_address) {
		this.delivery_address = delivery_address;
	}

	public String getShipment_status() {
		return shipment_status;
	}


	public void setShipment_status(String shipment_status) {
		this.shipment_status = shipment_status;
	}
}