// Products.java
package com.order.model;


import java.math.BigDecimal;
import java.util.*;

import javax.persistence.*;


@Entity
@Table(name = "PRODUCTS")

public class Products {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "PRODUCT_ID")
    private int productId;

    @Column(name = "PRODUCT_NAME")
    private String productName;

    @Column(name = "UNIT_PRICE",precision=10 ,scale=2)
    private BigDecimal unitPrice;

    @Column(name = "PRODUCT_COLOUR")
    private String colour;

    @Column(name = "PRODUCT_BRAND")
    private String brand;

    @Column(name = "PRODUCT_SIZE")
    private String size;

    @Column(name = "PRODUCT_RATING")
    private int rating;

    @OneToMany(mappedBy = "products", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Inventory> inventory;

	
	 @OneToMany(mappedBy = "products", fetch = FetchType.LAZY, cascade =CascadeType.ALL) 
	 private List<OrderItems> orderItems;
	 
    
	public long getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public List<Inventory> getInventory() {
		return inventory;
	}

	public void setInventory(List<Inventory> inventory) {
		this.inventory = inventory;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public List<OrderItems> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItems> orderItems) {
		this.orderItems = orderItems;
	}

	
    
    
		
	
}
