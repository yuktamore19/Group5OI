package com.order;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.order.repository.InventoryRepository;
import com.order.repository.StoresRepository;
import com.order.repository.ProductsRepository;

/*import com.order.repository.CustomersRepository;
import com.order.repository.InventoryRepository;
import com.order.repository.OrderItemsRepository;
import com.order.repository.OrdersRepository;
import com.order.repository.ProductsRepository;
import com.order.repository.ShipmentsRepository;
import com.order.repository.StoresRepository;*/

@SpringBootApplication
public class OrderInventoryApplication implements CommandLineRunner {

	@Autowired
	StoresRepository srepo;
	
	@Autowired
	ProductsRepository prepo;
	
	@Autowired
	InventoryRepository irepo;
	/*
	 * @Autowired OrdersRepository orepo;
	 * 
	 * @Autowired OrderItemsRepository oirepo;
	 * 
	 * @Autowired CustomersRepository crepo;
	 * 
	 * @Autowired ShipmentsRepository shiprepo;
	 */
	
	public static void main(String[] args) {
		SpringApplication.run(OrderInventoryApplication.class, args);
			
	}

	@Override
	public void run(String... args) throws Exception {
	
		
	}

}
